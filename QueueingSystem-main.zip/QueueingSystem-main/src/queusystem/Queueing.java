package queusystem;

public class Queueing {
    
}
